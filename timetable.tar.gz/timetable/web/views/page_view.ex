defmodule Timetable.PageView do
  use Timetable.Web, :view
end
