defmodule Timetable.LayoutView do
  use Timetable.Web, :view
end
