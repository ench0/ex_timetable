use Mix.Config

# In this file, we keep production configuration that
# you likely want to automate and keep it away from
# your version control system.
#
# You should document the content of this
# file or create a script for recreating it, since it's
# kept out of version control and might be hard to recover
# or recreate for your teammates (or you later on).
config :timetable, Timetable.Endpoint,
  secret_key_base: "/powRc14/W92F5lso+Kc1b02Io9kHmNNyww86Z6Q0injc1w842PLivqPSRm67F7s"
