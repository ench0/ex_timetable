defmodule Timetable.PageViewTest do
  use Timetable.ConnCase, async: true
end
