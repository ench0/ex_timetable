defmodule Timetable.LayoutViewTest do
  use Timetable.ConnCase, async: true
end
